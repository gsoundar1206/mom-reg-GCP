# mom-regression-suite

gcloud builds submit --tag gcr.io/ce-cxmo-dev/mom-robot-test-framework-suite

